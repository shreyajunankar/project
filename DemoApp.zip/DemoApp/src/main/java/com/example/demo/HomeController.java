package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.server.Jsp;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class HomeController {
	@Autowired
	JPARepo jparepo;
	
	@Autowired
	JPAEmployeeRepo jpaemployeerepo;
	
	@RequestMapping("/abc")
	public ModelAndView home() {
		
		System.out.println("hi");
		List<Student> studentinfo =new ArrayList<Student>();
		
		studentinfo=jparepo.findAll();
	
		System.out.println(studentinfo.get(0).getName());
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("studentinfo", studentinfo);
		
		mv.setViewName("home.jsp");
		return mv;
		
	}
	@RequestMapping("/home1")
	public Optional<Student> home1() {
		
		System.out.println("hi");
		
		Optional<Student> stud =Optional.empty();
		System.out.println("hi.....");

		stud=jparepo.findById(5);
           System.out.println(stud);
		return stud;
		
	}
	
	@RequestMapping("/home1jdbc")
	public List<Student> home1jdbc() throws SQLException {
		
		System.out.println("hi");
		List<Student> studentinfo =new ArrayList<Student>();
	 String QUERY = "SELECT * FROM student";

		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", 
				"sys as sysdba", "oracle");
		Statement stmt = conn.createStatement();
		         ResultSet rs = stmt.executeQuery(QUERY);
		         while(rs.next()){
		             //Display values
		        	 Student student = new Student(); 
		        	 student.setId(rs.getInt("id"));
		        	 student.setName(rs.getString("Name"));
		        	 student.setStandard(rs.getString("standard"));
		        	 student.setAge(rs.getInt("Age"));
		        	 studentinfo.add(student);
		          }		
		         return studentinfo;
		
	}
	@RequestMapping("/delete")
	public ModelAndView delete(int userId) {
		
		System.out.println("hi in delete");
		System.out.println(userId);
		jparepo.deleteById(userId);
		 List<Student> studentinfo =new ArrayList<Student>();
			
			studentinfo=jparepo.findAll();
		
			System.out.println(studentinfo);
			
			ModelAndView mv = new ModelAndView()
					;
			mv.addObject("studentinfo", studentinfo);
			
			mv.setViewName("home.jsp");
			return mv;
		
	}
	@RequestMapping("/add")
	public ModelAndView add(Student student) {
		
		System.out.println("hi in add"+student.getAge());
		jparepo.save(student);
		
		
List<Student> studentinfo =new ArrayList<Student>();
		
		studentinfo=jparepo.findAll();
	
		System.out.println(studentinfo.get(0).getName());
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("studentinfo", studentinfo);
		
		mv.setViewName("home.jsp");
		return mv;		
	}
	
	@RequestMapping("/addjdbc")
	public Student addjdbc(@RequestBody Student student) throws SQLException {
		
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", 
				"sys as sysdba", "oracle");
      

        PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO student VALUES (?, ?, ?, ?)") ;
            
        // Execute a query
        System.out.println("Inserting records into the table...");          
        preparedStatement.setInt(1, student.getId());
        preparedStatement.setString(2, student.getName());
        preparedStatement.setInt(3,student.getAge());
        preparedStatement.setString(4, student.getStandard());
        preparedStatement.execute();
		
		return student;
		
	}
	@RequestMapping("/add1")
	public Student add1(@RequestBody Student student) {
		
		System.out.println("hi in add");
		jparepo.delete(student);
      
	
		
		return  student;
		
	}
	@RequestMapping(value="/edit")
	public ModelAndView edit(Student student) {
		
		System.out.println("hi in add");
		System.out.println("as"+student.getId());
		jparepo.deleteById(student.getId());
		jparepo.save(student);
		
        List<Student> studentinfo =new ArrayList<Student>();
		
		studentinfo=jparepo.findAll();
	
		System.out.println(studentinfo.get(0).getName());
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("studentinfo", studentinfo);
		
		mv.setViewName("home.jsp");
		return mv;
		
	}
	
	@RequestMapping(value="/checkStudent")
	public void checkStudent() {
		
		System.out.println("inside checkStudent");
		List<Student> al=jparepo.findAll();
		
		for (Student student : al) {
			System.out.println(student.getName());
			System.out.println(student.getStandard());

		}
		
		
           Optional<Employee> emp=jpaemployeerepo.findByName("jayash");
		
		System.out.println(emp.get().getAge());
	}
}
