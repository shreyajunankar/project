package com.example.demo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class Studentrestcontroller {
	
	@GetMapping("/students")
	public HashSet<Students> getStudents(){
		
		HashSet theStudents= new HashSet();
		
		Students s1 = new Students("jayash", "acham");
		Students s2 = new Students("shreya", "acham");
		theStudents.add(s1);
		theStudents.add(s2);

		
		return theStudents;
	}
	

	@GetMapping("/students/{studentid}/{a}")
	public Students getStudents(@PathVariable int studentid,@PathVariable int a){
		
		ArrayList<Students> theStudents= new ArrayList<Students>();
		
		Students s1 = new Students("jayash", "acham");
		Students s2 = new Students("shreya", "acham");
		theStudents.add(s1);
		theStudents.add(s2);

		
		return  theStudents.get(studentid);
	}
	
	@GetMapping("/studentsReq")
	public Students getstudentsReq(@RequestParam int studentid,@RequestParam int a){
		
		ArrayList<Students> theStudents= new ArrayList<Students>();
		
		Students s1 = new Students("jayash", "acham");
		Students s2 = new Students("shreya", "acham");
		theStudents.add(s1);
		theStudents.add(s2);

		
		return  theStudents.get(studentid);
	}
	
	@RequestMapping("/studentsJson"	)
	public Students getstudentsJson(@RequestBody Students stud){
		
		return stud;
	}
	

}
