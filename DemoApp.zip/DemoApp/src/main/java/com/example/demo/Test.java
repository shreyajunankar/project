package com.example.demo;

import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String s= "Shreya";
		int count=0;
		int index=0;
		for (int i = 0; i <= s.length(); i++) {
			
			for (int j = 0; j < s.length(); j++) {
				if (s.charAt(i)==s.charAt(i))
					index++;
				
					
				
				
			}
			if(index==1) {
				index=i;
				break;
			}
		}
		
		System.out.println(index);
	}

}
