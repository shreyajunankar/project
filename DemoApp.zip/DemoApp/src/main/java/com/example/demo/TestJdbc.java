package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;

public class TestJdbc {

	@Autowired
	static JPAEmployeeRepo jpaemployeerepo;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e = new Employee();
		e.setAge(2);
		e.setId(3);
		e.setName("jayash");
		jpaemployeerepo.save(e);
		
		
		
	}
}
