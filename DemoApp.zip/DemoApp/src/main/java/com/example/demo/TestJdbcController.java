package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import antlr.collections.List;

@RestController
public class TestJdbcController {
	
	@Autowired
	Personjparepo personjparepo;
	
	@RequestMapping("/testJdbc")
	public void ABC() {
		
		System.out.println("enter into abc method");
		Persons p = new Persons();
		p.setAddress("dfvdfv");
		p.setCity("dfvdf");
		p.setFirstname("dfv");
		p.setPersonid(5);
		personjparepo.save(p);
		System.out.println("exit from abc method");

		
	}

	@RequestMapping("/getJdbc")
	public void getABC() {
		
		System.out.println("enter into getABC method");
		
	   java.util.List<Persons> al= personjparepo.findAll();
		System.out.println("exit from getABC method"+al);

		
	}
}
